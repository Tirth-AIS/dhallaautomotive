<?php

//Menu Supports
add_theme_support('menus');

//Register Menus
register_nav_menus(
    array(
        'top-menu' => _('Top Menu', 'theme'),
    )
);

/*require get_template_directory().'/contactus.php';
require get_template_directory().'/albumlist.php';*/




